import React, { useState, useEffect, useCallback, useRef } from 'react';
import { scrollBehavior } from '../../utils/motion';   // fix226: follows Settings > Animation
import { portalRoot } from '../../components/common/portalRoot';
import { roleFlags } from '../../utils/roles';
import { useSearchParams } from 'react-router-dom';
import { PaymentHealthDot, PaymentHealthLegend } from '../../components/common/PaymentHealth';
import ReactDOM from 'react-dom';
import { FiTrash2, FiSearch, FiX, FiPhone, FiPhoneCall, FiMapPin, FiClock, FiChevronDown, FiUser, FiFolderPlus, FiRefreshCw } from 'react-icons/fi';
import recoveryService from '../../services/recoveryService';
import { errorText } from '../../utils/errorText';
import { useAuth } from '../../hooks/useAuth';
import { splitPhones, telHref, prettyPhone, phoneSearchText } from '../../utils/phone';
import HardwareModal from '../../components/common/HardwareModal';
import HardwareButton from '../../components/common/HardwareButton';
import BackToTopButton from '../../components/common/BackToTopButton';
import { HeaderActions, HeaderButton } from '../../components/common/HeaderButton';
import styles from './RecoveryPortal.module.css';
import { LoadingState } from '../../components/common/LoadingState';
import modalStyles from '../../components/common/HardwareModal.module.css';
import ReasonPrompt from '../../components/common/ReasonPrompt';   // fix223
import { useReasonPrompt, DELETE_PICKS } from '../../components/common/useReasonPrompt';
import TabDock, { accentOf } from '../../components/common/TabDock';
import { useSwapMotion } from '../../hooks/useTabMotion';
const TABS = [
  { key: 'ALL', label: 'ALL DUE' },
  { key: 'CONTACTED', label: 'CONTACTED', accent: 'green' },
  { key: 'MISSED', label: 'MISSED', accent: 'red' },
  { key: 'SITE', label: 'SITE VISIT', accent: 'cyan' },
  { key: 'LOCKED', label: 'LOCKED', accent: 'yellow' },
];
function fmtD(s) { if (!s) return 'NEVER'; const d = new Date(s); const p = (x) => String(x).padStart(2, '0'); return p(d.getDate()) + '/' + p(d.getMonth() + 1) + '/' + d.getFullYear(); }
export default function RecoveryPortal() {
  // fix181 (6.10, 4.3): /recovery?client=<id> opens that client's card, or says why the client is not listed
  const [searchParams] = useSearchParams();
  const wantClient = searchParams.get('client');
  const [clientMsg, setClientMsg] = useState('');
  const [tab, setTab] = useState('ALL');
  const swapRef = useSwapMotion(tab);   // fix192: the list fades in gently when the tab changes
  const [counts, setCounts] = useState(null);
  const [stats, setStats] = useState(null);
  const [rows, setRows] = useState([]);
  const [tags, setTags] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [openId, setOpenId] = useState(null);
  const [sel, setSel] = useState(null);
  const [notes, setNotes] = useState([]);
  const [picked, setPicked] = useState(null);
  const [text, setText] = useState('');
  const [coWarn, setCoWarn] = useState(null);
  const [busy, setBusy] = useState(false);
  const [toasts, setToasts] = useState([]);
  const loadedOnce = useRef(false);
  const searchRef = useRef('');
  // fix170: rowsTab = which tab the cards on screen belong to; syncing = a fresh answer is on its way;
  // reqRef = newest request wins; cacheRef = last answer per tab so a revisited tab shows at once.
  const [rowsTab, setRowsTab] = useState(null);
  const [syncing, setSyncing] = useState(false);
  const reqRef = useRef(0);
  const cacheRef = useRef({});
  const pendingOpen = useRef(null);   // the client to open once its tab has loaded (declared before load uses it)
  const { user } = useAuth();
  const canManage = roleFlags(user).isManager;
  const toast = useCallback((msg, type) => { const id = Date.now() + Math.random(); setToasts((p) => [...p, { id, msg, type: type || 'info' }]); setTimeout(() => setToasts((p) => p.filter((t) => t.id !== id)), 4000); }, []);
  // fix170: a plain tab click asks for the queue ONLY; counts / tags / stats come on first open, REFRESH and after a call.
  const load = useCallback((silent, forceMeta) => {
    const myReq = ++reqRef.current;
    const withMeta = !!forceMeta || !!silent || !loadedOnce.current;
    if (!silent) { setLoading(!loadedOnce.current); setSyncing(true); }
    const calls = [recoveryService.getQueue(tab)];
    if (withMeta) calls.push(recoveryService.getQueues(searchRef.current), recoveryService.getTags(), recoveryService.getStats());
    Promise.all(calls)
      .then((r) => {
        if (myReq !== reqRef.current) return;   // a newer click already replaced this request
        if (withMeta) { setCounts(r[1].data || r[1]); setTags(r[2].data || r[2]); setStats(r[3].data || r[3]); }
        const list = r[0].data || r[0];
        cacheRef.current[tab] = list;
        setRows(list); setRowsTab(tab);
        if (pendingOpen.current) {
          const hit = list.find((x) => x.id === pendingOpen.current);
          pendingOpen.current = null;
          if (hit) {
            setOpenId(hit.id);
            setTimeout(() => { const el = document.getElementById('rc-' + hit.id); if (el) el.scrollIntoView({ block: 'center', behavior: scrollBehavior() }); }, 80);
          } else setOpenId(list.length ? list[0].id : null);
        } else {
          setOpenId(list.length ? list[0].id : null);
        }
        loadedOnce.current = true;
        setLoading(false); setSyncing(false);
      }).catch(() => { if (myReq !== reqRef.current) return; setLoading(false); setSyncing(false); toast('Could not load recovery queue.', 'error'); });
  }, [tab, toast]);
  useEffect(() => { load(); }, [load]);
  useEffect(() => {
    if (!wantClient) return undefined;
    let alive = true;
    recoveryService.getClientDossier(wantClient).then((d) => {
      if (!alive || !d) return;
      const st = d.recoveryState;
      if (!st) {
        setClientMsg((d.name || 'This client') + ' is not on the Recovery list: nothing that counts is owed (paid up, only Pending projects, or a project in its first month).');
        return;
      }
      setClientMsg('');
      setTab(st === 'SITE' ? 'SITE' : st === 'LOCKED' ? 'LOCKED' : 'ALL');
      setOpenId(d.id);
      setSearch(d.name || '');
    }).catch(() => { if (alive) setClientMsg('That client could not be found.'); });
    return () => { alive = false; };
  }, [wantClient]);
  // fix170: a tab already opened this visit shows at once; a tab never opened shows the loading panel, never the old tab's cards
  useEffect(() => {
    const cached = cacheRef.current[tab];
    if (cached) { setRows(cached); setRowsTab(tab); setOpenId(null); }
  }, [tab]);
  useEffect(() => {
    searchRef.current = search;
    if (!search && !loadedOnce.current) return undefined;   // fix170: the first load already fetched the counts
    const t = setTimeout(() => {
      recoveryService.getQueues(search).then((r) => setCounts(r.data || r)).catch(() => {});
    }, 250);
    return () => clearTimeout(t);
  }, [search]);
  // fix220: the history says when it is loading or could not load (it used to stay silently empty)
  const [notesState, setNotesState] = useState('');
  const loadNotes = (cid) => {
    setNotesState('loading');
    recoveryService.getNotes(cid)
      .then((r) => { setNotes(Array.isArray(r.data) ? r.data : []); setNotesState(''); })
      .catch(() => { setNotes([]); setNotesState('error'); });
  };
  const open = (c) => { setSel(c); setPicked(null); setText(''); setNotes([]); loadNotes(c.id); };
  const jump = (co) => {
    const target = co.state === 'LOCKED' ? 'LOCKED' : co.state === 'SITE' ? 'SITE' : 'ALL';
    pendingOpen.current = co.id;
    if (target !== tab) setTab(target); else load(true);
  };
  const save = () => {
    if (!picked || !sel) return;
    setBusy(true);
    recoveryService.logNote({ clientId: sel.id, tag: picked.tag, text: text })
      .then((r) => { setBusy(false); setSel(null); toast('Logged.', 'success'); if (r && r.data && r.data.coOwnerWarning) setCoWarn(r.data.coOwnerWarning); load(true); })
      .catch((e) => { setBusy(false); toast(errorText(e), 'error'); });   // fix224: plain words, never a code word
  };
  // fix223 (David): DELETE opens the shared "why?" window; the reason goes to the audit log. While it is deleting the
  // button says DELETING... and cannot be pressed again; the history and the queue reload afterwards.
  const [deleting, setDeleting] = useState(null);
  const { reasonState, askReason, closeReason } = useReasonPrompt();
  const askDelete = (noteId) => {
    if (deleting) return;
    askReason({
      title: 'DELETE CALL NOTE', okLabel: 'DELETE', picks: DELETE_PICKS.CALL,
      message: 'Delete this call note? The client\u2019s last-contact date and score are put back.',
      run: async (reason) => {
        setDeleting(noteId);
        try { await recoveryService.deleteNote(noteId, reason); toast('Call note deleted.', 'warn'); }
        finally { setDeleting(null); loadNotes(sel.id); load(true); }
      },
    });
  };
  const term = search.toLowerCase().replace(/\s+/g, '');
  const rowsF = (rowsTab !== tab ? [] : rows).filter((c) => !term || [c.name, c.nin, c.phone, phoneSearchText(c.phone), c.lastTag, c.district, c.subCounty, c.village, c.placeText, ...(c.indexes || [])].join(' ').toLowerCase().replace(/\s+/g, '').indexOf(term) >= 0);
  return (
    <div className={styles.container}>
      <header className={styles.pageHeader}>
        <div className={styles.headerLeft}>
          <h1 className={styles.title}>Recovery Cockpit</h1>
          <p className={styles.subtitle}>Call logs only - numbers only</p>
        </div>
        <HeaderActions>
          <HeaderButton icon={FiRefreshCw} label="REFRESH" busy={loading || syncing}
            tip="Reload the queues, counts and call stats" onClick={() => load(false, true)} />
        </HeaderActions>
      </header>
      <div className={styles.countsHUD}>
        <div className={`${styles.countCard} ${styles.statGreen}`}><label>TODAY'S CALLS</label><strong>{stats ? stats.callsToday : '-'}</strong></div>
        <div className={`${styles.countCard} ${styles.statCyan}`}><label>MONTH'S CALLS</label><strong>{stats ? stats.callsMonth : '-'}</strong></div>
        <div className={`${styles.countCard} ${styles.statAmber}`}><label>LONGEST WAIT</label><strong>{stats ? stats.longestWait : '-'}</strong></div>
        <div className={`${styles.countCard} ${styles.statRed}`}><label>MONTH'S MISS</label><strong>{stats ? stats.missMonth : '-'}</strong></div>
      </div>
      <div className={styles.stickyRail}>
      <div className={styles.stickyTabs}>
        <div className={styles.tabSearch}>
          <FiSearch className={styles.searchIcon} aria-hidden="true" />
          <input type="search" className={styles.searchInput} placeholder="Search name, NIN, phone, index, location..." value={search} onChange={(e) => setSearch(e.target.value)} aria-label="Search recovery queue" autoComplete="off" />
          {search && (<button type="button" className={styles.searchClearBtn} onClick={() => setSearch('')} aria-label="Clear search"><FiX aria-hidden="true" /></button>)}
        </div>
        <TabDock
          className={styles.dockSlot} mode="tab" label="Recovery queues"
          items={TABS.map((t) => ({ key: t.key, label: t.label, accent: t.accent, count: counts ? counts[t.key] : '-' }))}
          value={tab} onChange={setTab}
        />
      </div>
      </div>
      <div className={styles.dotLegend}><PaymentHealthLegend /></div>
      {clientMsg && <div className={styles.dotLegend} role="status">{clientMsg}</div>}
      {(loading && rows.length === 0) || (syncing && rowsTab !== tab) ? (
        <LoadingState label="SYNCING RECOVERY QUEUE..." />
      ) : (
        <div className={`${styles.list} ${loading || syncing ? styles.refreshing : ''}`} data-tab-accent={accentOf(TABS, tab)} ref={swapRef}>
          {rowsF.map((c) => {
            const isOpen = openId === c.id;
            return (
              <article key={c.id} id={'rc-' + c.id} className={`${styles.rowCard} ${isOpen ? styles.rowOpen : ''}`}>
                <button type="button" className={styles.rowHead} onClick={() => setOpenId(isOpen ? null : c.id)} aria-expanded={isOpen}>
                  <span className={styles.cardHeadLeft}>
                    <FiPhoneCall className={styles.headIcon} aria-hidden="true" />
                    <span className={styles.cname}>{c.name || c.nin || 'UNKNOWN CLIENT'}</span>
                  </span>
                  <span className={styles.headerRight}>
                    <span className={`${styles.callPos} ${styles['qp_' + tab]}`}>{c.position ? tab + ' #' + c.position + '/' + c.queueTotal : tab}</span>
                    <PaymentHealthDot days={c.daysSincePayment} />
                    {c.lastTag && (<span className={c.lastTone === 'POSITIVE' ? styles.chipPos : c.lastTone === 'NEGATIVE' ? styles.chipNeg : styles.chipNone}>{c.lastTag}</span>)}
                    {c.problem && <span className={styles.chipNeg} title="One of this client's plots is flagged as a PROBLEM. Open the folder to read what it is before calling.">PROBLEM</span>}
                    {c.dayMiss > 0 && <span className={styles.dayChip}>day {c.dayMiss}/30</span>}
                    <span className={styles.reason}>{c.reason}</span>
                    <FiChevronDown className={`${styles.chev} ${isOpen ? styles.chevOpen : ''}`} aria-hidden="true" />
                  </span>
                </button>
                {isOpen && (
                  <div className={styles.rowBody}>
                    <span className={styles.rowInfo}>
                    <span className={styles.secBlock}>
                      <label className={styles.secLabel}>CONTACT</label>
                      <span className={styles.nin}>{c.nin}</span>
                      <span className={styles.monoRow}><FiPhoneCall aria-hidden="true" />{splitPhones(c.phone).map((ph, i) => (<React.Fragment key={i}>{i > 0 && <span className={styles.mono}> / </span>}<a className={styles.mono} href={telHref(ph)} onClick={(e) => e.stopPropagation()} style={{ textDecoration: 'none' }}>{prettyPhone(ph)}</a></React.Fragment>))}</span>
                      {(c.places && c.places.length > 0 ? c.places : (c.district ? [c.district + (c.subCounty ? ' - ' + c.subCounty : '') + (c.village ? ' - ' + c.village : '')] : [])).map((pl, i) => (<span key={i} className={styles.loc}><FiMapPin aria-hidden="true" /> {pl}</span>))}
                    </span>
                    <span className={styles.secBlock}>
                      <label className={styles.secLabel}>PROJECTS ({c.projectCount || (c.projectIds || []).length})</label>
                      <span className={styles.projLine}>
                        {(c.projectIds || []).map((pid, i) => (<a key={pid} className={styles.projLink} href={'/folder/' + pid} onClick={(e) => e.stopPropagation()} title={(c.problemIds || []).includes(pid) ? 'This plot is flagged as a PROBLEM' : 'Open this folder'} style={(c.problemIds || []).includes(pid) ? { color: '#f87171' } : undefined}>#{c.indexes[i] || pid}{(c.problemIds || []).includes(pid) ? ' (PROBLEM)' : ''}</a>))}
                      </span>
                      {(c.coOwners || []).length > 0 && (
                        <span className={styles.coLine}>
                          <FiUser aria-hidden="true" /> Joint with:
                          {(c.coOwners || []).map((co) => (
                            <button key={co.id} type="button" className={styles.coChip} onClick={(e) => { e.stopPropagation(); jump(co); }}>
                              {co.name} <span className={styles.coCount}>({co.projects})</span>
                            </button>
                          ))}
                        </span>
                      )}
                    </span>
                    <span className={styles.secBlock}>
                      <label className={styles.secLabel}>CALL STATUS</label>
                      <span className={styles.attemptLine}><FiClock aria-hidden="true" /> Good calls this 30 days: {c.calls30}/2 - Misses: {c.miss30}</span>
                      {c.unlock && (<span className={styles.lockBanner}><FiClock aria-hidden="true" /> Resting until {fmtD(c.unlock)} - read only.</span>)}
                    </span>
                    </span>
                    <span className={styles.rowActions}>
                      <button type="button" className={styles.cardBtn} onClick={() => open(c)} disabled={syncing}
                        title={c.state === 'LOCKED' ? 'Resting: see the call history (read only). A Manager can delete a wrong call note there.' : 'Log a call and see the call history'}><FiPhone aria-hidden="true" /> CALL LOG</button>
                      {(c.projectIds || []).length > 0 && (<button type="button" className={styles.cardBtn2} onClick={() => { window.location.href = '/folder/' + c.projectIds[0]; }}><FiFolderPlus aria-hidden="true" /> OPEN FOLDER</button>)}
                    </span>
                  </div>
                )}
                {isOpen && (<>
                  <span className={styles.pinsBottom} aria-hidden="true"><i /><i /><i /><i /></span>
                  <span className={styles.decorBl} aria-hidden="true" />
                  <span className={styles.decorBr} aria-hidden="true" />
                </>)}
              </article>
            );
          })}
          {rowsF.length === 0 && (<div className={styles.emptyState}><span>{term ? 'NO RECORDS MATCH "' + term.toUpperCase() + '"' : 'QUEUE CLEAR'}</span></div>)}
        </div>
      )}
      <HardwareModal isOpen={!!sel} onClose={() => setSel(null)} title={sel ? 'CALL LOG - ' + sel.name : 'CALL LOG'} lockBackdrop>
        {sel && (<>
          <div className={styles.modalBody}>
          <div className={styles.metaRow}><span className={styles.nin}>{sel.nin}</span><span>{splitPhones(sel.phone).map((ph, i) => (<React.Fragment key={i}>{i > 0 && <span className={styles.mono}> / </span>}<a className={styles.mono} href={telHref(ph)} style={{ textDecoration: 'none' }}>{prettyPhone(ph)}</a></React.Fragment>))}</span></div>
          {(sel.unlock || sel.state === 'LOCKED') && (<div className={styles.lockBanner}><FiClock aria-hidden="true" /> Resting until {fmtD(sel.unlock)} - read only.</div>)}
          <div className={styles.tagwall}>
            <label className={styles.wallLabel}>CALL (WE SPOKE)</label>
            <div className={styles.wallRow}>
              {tags.filter((t) => t.tone === 'POSITIVE').map((t) => (
                <button type="button" key={t.tag} className={styles.tagPos + (picked && picked.tag === t.tag ? ' ' + styles.tagOn : '')} disabled={(!!sel.unlock || sel.state === 'LOCKED')} onClick={() => setPicked(t)}>{t.tag}</button>
              ))}
            </div>
            <label className={styles.wallLabel}>MISSED (NO CONTACT)</label>
            <div className={styles.wallRow}>
              {tags.filter((t) => t.tone === 'NEGATIVE').map((t) => (
                <button type="button" key={t.tag} className={styles.tagNeg + (picked && picked.tag === t.tag ? ' ' + styles.tagOn : '')} disabled={(!!sel.unlock || sel.state === 'LOCKED')} onClick={() => setPicked(t)}>{t.tag}</button>
              ))}
            </div>
          </div>
          <div className={modalStyles.modalField}>
            <label className={modalStyles.modalLabel}>NOTE (OPTIONAL)</label>
            <input type="text" className={modalStyles.modalInput} value={text} onChange={(e) => setText(e.target.value)} aria-label="Optional note" />
          </div>
          <div className={styles.histSection}>
            <label className={styles.wallLabel}>HISTORY</label>
            {notes.map((n) => (
              <div key={n.id} className={styles.histRow}>
                <span className={n.tone === 'POSITIVE' ? styles.chipPos : n.tone === 'NEGATIVE' ? styles.chipNeg : styles.chipNone}>{n.tag}</span>
                <span className={styles.histMeta}>{n.author || 'SYSTEM'} - {fmtD(n.createdAt)}</span>
                {n.text && <span className={styles.histText}>{n.text}</span>}
                {canManage && n.source === 'RECOVERY' && n.countsAsAttempt && n.author && (
                  <button type="button" disabled={!!deleting} className={`${styles.histDelete} ${deleting === n.id ? styles.histDeleteArmed : ''}`} aria-label="Delete this call note"
                    title="Delete this call note (Manager and above). You are asked why; the audit log keeps the reason."
                    onClick={() => askDelete(n.id)}>
                    <FiTrash2 aria-hidden="true" />
                  </button>
                )}
              </div>
            ))}
            {notesState === 'loading' && (<div className={styles.histEmpty}>LOADING THE CALL HISTORY...</div>)}
            {notesState === 'error' && (<div className={styles.histEmpty} role="alert">COULD NOT LOAD THE CALL HISTORY. <button type="button" className={styles.histRetry} onClick={() => loadNotes(sel.id)} title="Try loading the history again">TRY AGAIN</button></div>)}
            {!notesState && notes.length === 0 && (<div className={styles.histEmpty}>NO CALLS LOGGED YET.</div>)}
          </div>
          </div>
          <div className={modalStyles.modalFooter}>
            <HardwareButton type="button" onClick={save} loading={busy} icon={FiPhone} disabled={!picked || (!!sel.unlock || sel.state === 'LOCKED')}>LOG OUTCOME</HardwareButton>
          </div>
        </>)}
      </HardwareModal>
      {coWarn && (
        <div className={styles.coWarnBanner} role="status">
          <span>{coWarn}</span>
          <button type="button" className={styles.coWarnDismiss} onClick={() => setCoWarn(null)} aria-label="Dismiss notice">&times;</button>
        </div>
      )}
      <BackToTopButton />
      <ReasonPrompt state={reasonState} onClose={closeReason} />
      {typeof document !== 'undefined' && ReactDOM.createPortal(
        <div className={styles.toastStack} role="region" aria-label="Notifications" aria-live="polite">
          {toasts.map((t) => (<div key={t.id} className={`${styles.toast} ${styles['toast_' + t.type]}`}>{t.msg}</div>))}
        </div>, portalRoot())}
    </div>
  );
}
