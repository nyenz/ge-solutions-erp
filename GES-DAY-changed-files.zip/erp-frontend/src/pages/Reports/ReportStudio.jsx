// PATH: erp-frontend/src/pages/Reports/ReportStudio.jsx
// GOLDEN SEED -- REPORT STUDIO (fix84): scope bar + catalogue + viewer.
// One chain: dataset -> entity -> period -> columns -> sort -> report ->
// chart + table + CSV + PDF. Every control recomputes the same row set, so
// chart, table and downloads can never disagree.
import { GES_GLOBE } from '../../components/print/GesMark';   // fix233: the real GES logo
import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { FiSearch, FiX, FiChevronDown, FiAlertCircle, FiCheck } from 'react-icons/fi';
import { Chart } from '../../components/common/Charts';
import {
  DATASETS, datasetsFor, fieldsFor, fieldByKey, applyFilters,
  groupRows, formatValue, toCSV, downloadCSV,
} from './reportData';
import { CATALOGUE, ENTITIES, GROUPS, DEFAULTS } from './reportsCatalog';
import CornerDecor from '../../components/ui/CornerDecor';
import HardwareDatePicker from '../../components/common/HardwareDatePicker';
import styles from './ReportStudio.module.css';
import { periodRange, localISO } from '../../utils/reportPeriod';   // fix190: device calendar, not UTC
import useScrollEdges from '../../hooks/useScrollEdges';

const PERIODS = ['TODAY','THIS WEEK','LAST WEEK','THIS MONTH','LAST MONTH','THIS QUARTER','THIS YEAR','LAST YEAR','ALL TIME','CUSTOM'];
const CHART_MAP = { BAR: 'bars', COLUMN: 'column', LINE: 'line', AREA: 'line', DONUT: 'donut' };
const CHART_OPTS = ['NONE','BAR','COLUMN','LINE','AREA','DONUT'];
const RECENT_KEY = 'gs.reports.recent.v1';
const SAMPLE = 8;
const SEARCH_HINT = {
  PROJECTS: 'Project index, plot, owner name, NIN...',
  CLIENTS: 'Client name, NIN, phone...',
  PAYMENTS: 'Receipt no, project, client...',
  EXPENSES: 'Item, category, project...',
  COMPANY: 'Any row across the company...',
};

const ReportStudio = ({ canSeeMoney = false, reloadToken = 0 }) => {
  const available = useMemo(() => datasetsFor(canSeeMoney), [canSeeMoney]);
  const [datasetKey, setDatasetKey] = useState(available[0]?.key || 'PROJECTS');
  const sourceRailRef = useScrollEdges({ wheel: true, activeKey: datasetKey });   // fix183: sideways dataset bar
  const dataset = DATASETS[datasetKey] || available[0];
  const [rows, setRows] = useState([]);
  const countsRef = useRef({});
  const cacheRef = useRef({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [loadNote, setLoadNote] = useState('');   // fix181 (10.7, 16.10e): "showing the newest N of M"
  const [entity, setEntity] = useState(null);
  const [period, setPeriod] = useState('THIS MONTH');
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [columns, setColumns] = useState([]);
  const [sort, setSort] = useState({ col: '', dir: 'asc' });
  const [search, setSearch] = useState('');
  const [groupTab, setGroupTab] = useState('ALL');
  const [readId, setReadId] = useState(null);
  const [appliedId, setAppliedId] = useState(null);
  // fix227 (David): more than one chart at a time (e.g. DONUT + COLUMN), on screen and in the PDF
  const [chartModes, setChartModes] = useState([]);
  const chartOn = chartModes.length > 0;
  const [recent, setRecent] = useState(() => {
    try { return JSON.parse(window.localStorage.getItem(RECENT_KEY) || '[]'); } catch { return []; }
  });
  const [colOpen, setColOpen] = useState(false);
  const [sortOpen, setSortOpen] = useState(false);
  const [entOpen, setEntOpen] = useState(false);
  const [chartOpen, setChartOpen] = useState(false);
  const [scopeOpen, setScopeOpen] = useState(true);
  const [catOpen, setCatOpen] = useState(true);
  const [entQuery, setEntQuery] = useState('');
  const colRef = useRef(null);
  const sortRef = useRef(null);
  const entRef = useRef(null);
  const chartRef = useRef(null);
  const chartDdRef = useRef(null);
  useEffect(() => {
    const h = (e) => {
      if (colRef.current && !colRef.current.contains(e.target)) setColOpen(false);
      if (sortRef.current && !sortRef.current.contains(e.target)) setSortOpen(false);
      if (entRef.current && !entRef.current.contains(e.target)) setEntOpen(false);
      if (chartDdRef.current && !chartDdRef.current.contains(e.target)) setChartOpen(false);
    };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, []);
  const fields = useMemo(() => fieldsFor(dataset, canSeeMoney), [dataset, canSeeMoney]);
  const fieldByLabelMap = useMemo(() => {
    const map = {};
    fields.forEach(fld => { map[fld.label] = fld; });
    return map;
  }, [fields]);
  const load = useCallback(async (key) => {
    const ds = DATASETS[key];
    if (!ds) return;
    setLoading(true);
    setError('');
    setLoadNote('');
    try {
      const data = await ds.load();
      const list = Array.isArray(data) ? data : [];
      cacheRef.current[key] = list;
      setRows(list);
      setLoadNote((data && data.note) || '');
    } catch (err) {
      cacheRef.current[key] = [];
      setRows([]);
      // fix222: say what really happened instead of guessing
      const status = err && err.response && err.response.status;
      const what = ds.label.toLowerCase();
      setError(!status ? 'No reply from the server while loading ' + what + ' (the internet is down, or the server is waking up). Press REFRESH in a few seconds.'
        : status === 401 || status === 403 ? 'Your rank cannot open ' + what + ' in Reports.'
        : 'The server could not load ' + what + ' this time. Press REFRESH to try again.');
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => { load(datasetKey); }, [datasetKey, load]);
  useEffect(() => {
    let alive = true;
    const put = (k, v) => { countsRef.current[k] = v; };
    available.forEach(ds => {
      if (ds.key === datasetKey || cacheRef.current[ds.key]) return;
      ds.load().then(data => {
        if (!alive) return;
        const list = Array.isArray(data) ? data : [];
        cacheRef.current[ds.key] = list;
        put(ds.key, list.length);
      }).catch(() => { if (alive) { cacheRef.current[ds.key] = []; put(ds.key, 0); } });
    });
    return () => { alive = false; };
  }, [available, datasetKey]);
  useEffect(() => {
    if (countsRef.current[datasetKey] !== rows.length) {
      countsRef.current[datasetKey] = rows.length;
    }
  }, [datasetKey, rows.length]);
  const firstRun = useRef(true);
  useEffect(() => {
    if (firstRun.current) { firstRun.current = false; return; }
    load(datasetKey);
  }, [reloadToken, datasetKey, load]);
  useEffect(() => {
    const ds = DATASETS[datasetKey];
    if (!ds) return;
    const allowed = fieldsFor(ds, canSeeMoney).map(f => f.key);
    const fieldMap = {};
    fieldsFor(ds, canSeeMoney).forEach(f => { fieldMap[f.label] = f; });
    setEntity(null); setReadId(null);
    setGroupTab('ALL'); setSearch('');
    const sub = fieldsFor(ds, canSeeMoney).find(f => f.label === 'Sub-County');
    // fix124: land on the dataset's own default report (the
    // catalogue's pinned DEFAULT VIEW row) instead of an empty
    // viewer -- same as clicking "Use This Report" on it by hand.
    const dName = (DEFAULTS[datasetKey] || {}).ALL || '';
    const dDef = CATALOGUE.find(d => d.title === dName && d.ds === datasetKey && (!d.money || canSeeMoney)) || null;
    if (dDef) {
      setAppliedId(dDef.id);
      const dCols = (dDef.cols || []).map(l => (fieldMap[l] || {}).key).filter(Boolean).filter(k => allowed.includes(k));
      setColumns(dCols.length ? dCols : ds.defaultColumns.filter(c => allowed.includes(c)));
      setSort(dDef.sort ? { col: dDef.sort.col, dir: dDef.sort.dir } : (sub ? { col: sub.label, dir: 'asc' } : { col: '', dir: 'asc' }));
      setChartModes(dDef.chart && dDef.chart !== 'NONE' ? [dDef.chart] : []);
    } else {
      setAppliedId(null);
      setColumns(ds.defaultColumns.filter(c => allowed.includes(c)));
      setSort(sub ? { col: sub.label, dir: 'asc' } : { col: '', dir: 'asc' });
      setChartModes([]);
    }
  }, [datasetKey, canSeeMoney]);

  const entityTypes = useMemo(() => ENTITIES[datasetKey] || [], [datasetKey]);
  const entityValues = (type) => {
    const t = entityTypes.find(x => x.type === type);
    if (!t) return [];
    const fld = fieldByLabelMap[t.field];
    if (!fld) return [];
    const seen = [];
    rows.forEach(r => { const v = fld.get(r); if (v && seen.indexOf(v) < 0) seen.push(v); });
    return seen.sort().slice(0, 40);
  };
  const catalogue = useMemo(() => CATALOGUE.filter(d =>
    d.ds === datasetKey && (!d.money || canSeeMoney) &&
    ((entity ? (d.scopes || []).indexOf(entity.type) >= 0 : (d.scopes || []).indexOf('ALL') >= 0))
  ), [datasetKey, canSeeMoney, entity]);
  const searched = useMemo(() => {
    const q = search.trim().toUpperCase();
    if (!q) return catalogue;
    return catalogue.filter(d => (d.title + ' ' + d.desc).toUpperCase().indexOf(q) >= 0);
  }, [catalogue, search]);
  useEffect(() => {
    if (groupTab !== 'ALL' && !searched.some(d => d.group === groupTab)) setGroupTab('ALL');
  }, [searched, groupTab]);
  const listed = groupTab === 'ALL' ? searched : searched.filter(d => d.group === groupTab);
  const appliedDef = CATALOGUE.find(d => d.id === appliedId) || null;
  const defaultName = (DEFAULTS[datasetKey] || {})[entity ? entity.type : 'ALL'] || '';
  const defaultDef = CATALOGUE.find(d => d.title === defaultName && d.ds === datasetKey && (!d.money || canSeeMoney)) || null;
  // fix125: recent ids are stored globally across all datasets,
  // but the chip row should only reflect this data source --
  // filter to reports whose .ds matches what's on screen.
  const recentDefs = recent.map(id => CATALOGUE.find(d => d.id === id)).filter(Boolean).filter(d => d.ds === datasetKey);
  const restList = listed.filter(d => !defaultDef || d.id !== defaultDef.id);
  const entMatches = useMemo(() => {
    const q = entQuery.trim().toUpperCase();
    if (!q) return [];
    const out = [];
    entityTypes.forEach(t => {
      entityValues(t.type).forEach(v => {
        if (String(v).toUpperCase().indexOf(q) >= 0) out.push({ type: t.type, label: t.label, value: v });
      });
    });
    return out.slice(0, 15);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [entQuery, entityTypes, rows]);

  const toggleColumn = (key) => setColumns(c => (c.indexOf(key) >= 0 ? c.filter(k => k !== key) : [...c, key]));
  const applyDef = (def) => {
    setAppliedId(def.id);
    setReadId(null);
    const keys = (def.cols || []).map(l => (fieldByLabelMap[l] || {}).key).filter(Boolean);
    const allowed = fields.map(f => f.key);
    if (keys.length) setColumns(keys.filter(k => allowed.includes(k)));
    if (def.sort) setSort({ col: def.sort.col, dir: def.sort.dir });
    setChartModes(def.chart && def.chart !== 'NONE' ? [def.chart] : []);
    const next = [def.id].concat(recent.filter(x => x !== def.id)).slice(0, 6);
    setRecent(next);
    try { window.localStorage.setItem(RECENT_KEY, JSON.stringify(next)); } catch { /* private mode */ }
  };
  const periodHuman = () => {
    const labels = { TODAY: 'today', 'THIS WEEK': 'this week', 'LAST WEEK': 'last week', 'THIS MONTH': 'this month', 'LAST MONTH': 'last month', 'THIS QUARTER': 'this quarter', 'THIS YEAR': 'this year', 'LAST YEAR': 'last year', 'ALL TIME': 'since records began' };
    if (period !== 'CUSTOM') return labels[period] || period;
    let a = from || '..';
    let b = to || '..';
    if (from && to && from > to) { a = to; b = from; }
    return 'between ' + a + ' and ' + b;
  };
  const readout = (def) => {
    let text = def.desc;
    text += entity ? (' For ' + entity.label.toLowerCase() + ' ' + entity.value + '.') : (' Whole company.');
    text += def.period ? (' Period: ' + periodHuman() + '.') : (' Right-now snapshot.');
    const sc = def.sort || { col: 'first column', dir: 'asc' };
    text += ' Sorted by ' + sc.col + ' ' + (sc.dir === 'desc' ? 'highest first.' : 'A to Z.');
    return text;
  };
  const catRowNode = (def, isDefault) => {
    const isApplied = appliedId === def.id;
    const isOpen = readId === def.id;
    const rowCls = styles.row
      + (isOpen ? ' ' + styles.rowOpen : '')
      + (isApplied ? ' ' + styles.rowApplied : '')
      + (isDefault ? ' ' + styles.rowDefault : '');
    return (
      <div key={def.id} className={rowCls}>
        <button className={styles.rowHead} onClick={() => setReadId(isOpen ? null : def.id)} aria-expanded={isOpen}
          title={isOpen ? 'Hide what this report shows' : def.desc + ' Press to read more and use it.'}>
          <span className={styles.rowMain}>
            <span className={styles.name}>{isDefault ? 'DEFAULT VIEW: ' : ''}{def.title}{isApplied && <span className={styles.appliedTag}>APPLIED</span>}</span>
            <span className={styles.desc}>{def.desc}</span>
          </span>
          <span className={styles.rightMeta}>
            <span className={styles.rows}>{liveCount(def)} ROWS</span>
            <span className={styles.tag}>{def.chart !== 'NONE' ? def.chart : 'TABLE'} &middot; {def.group}</span>
            <FiChevronDown className={styles.chev} aria-hidden="true" />
          </span>
        </button>
        {isOpen && (
          <div className={styles.readout}>
            <div className={styles.readoutText}>{readout(def)}</div>
            <button className={styles.useBtn} onClick={() => applyDef(def)} disabled={isApplied} title={isApplied ? 'This report is on screen below.' : 'Show this report below: its chart, table, CSV and PDF.'}>{isApplied ? 'Applied \u2713' : 'Use This Report'}</button>
          </div>
        )}
      </div>
    );
  };

  /* ── viewer pipeline: one row set feeds chart, table, CSV, PDF ── */
  const entityRows = useMemo(() => {
    if (!entity) return rows;
    const et = entityTypes.find(t => t.type === entity.type);
    const fld = et ? fieldByLabelMap[et.field] : null;
    if (!fld) return rows;
    return rows.filter(r => String(fld.get(r) || '').toLowerCase() === String(entity.value).toLowerCase());
  }, [rows, entity, entityTypes, fieldByLabelMap]);
  const scopeRows = useMemo(() => {
    let list = entityRows;
    if (period !== 'ALL TIME') {
      const rng = periodRange(period, from, to);
      const fld = dataset.dateField ? fieldByLabelMap[dataset.dateField] : null;
      if (rng && fld) list = list.filter(r => {
        const v = fld.get(r);
        if (!v) return false;
        const d = String(v).slice(0, 10);
        return d >= rng[0] && d <= rng[1];
      });
    }
    return list;
  }, [entityRows, dataset, fieldByLabelMap, period, from, to]);
  const viewerRows = useMemo(() => {
    const def = appliedDef;
    if (!def) return [];
    let list = def.period ? scopeRows : entityRows;
    // fix181 (10.8): a report may carry several filters (for example a list of audit codes AND "not SYSTEM")
    if (def.filter) {
      const conds = [].concat(def.filter).map(fl => ({ fld: fieldByLabelMap[fl.field], fl })).filter(x => x.fld)
        .map(({ fld, fl }) => ({ field: fld.key, op: fl.op, value: fl.value }));
      if (conds.length) list = applyFilters(list, dataset, conds, 'AND', '');
    }
    return list;
  }, [appliedDef, scopeRows, entityRows, fieldByLabelMap, dataset]);
  const scopedCount = useCallback((key) => {
    const ds = DATASETS[key];
    if (!ds) return 0;
    let list = key === datasetKey ? rows : (cacheRef.current[key] || []);
    if (entity) {
      const et = (ENTITIES[key] || []).find(t => t.type === entity.type);
      const f = et ? fieldsFor(ds, canSeeMoney).find(x => x.label === et.field) : null;
      if (f) list = list.filter(r => String(f.get(r) || '').toLowerCase() === String(entity.value).toLowerCase());
    }
    if (period !== 'ALL TIME' && ds.dateField) {
      const rng = periodRange(period, from, to);
      const f = fieldsFor(ds, canSeeMoney).find(x => x.label === ds.dateField);
      if (rng && f) list = list.filter(r => { const v = f.get(r); if (!v) return false; const d = String(v).slice(0, 10); return d >= rng[0] && d <= rng[1]; });
    }
    return list.length;
  }, [datasetKey, rows, entity, period, from, to, canSeeMoney]);
  const liveCount = useCallback((def) => {
    let list = def.ds === datasetKey ? scopeRows : (cacheRef.current[def.ds] || []);
    if (def.ds !== datasetKey) {
      const ds = DATASETS[def.ds];
      if (ds && entity) {
        const et = (ENTITIES[def.ds] || []).find(t => t.type === entity.type);
        const f = et ? fieldsFor(ds, canSeeMoney).find(x => x.label === et.field) : null;
        if (f) list = list.filter(r => String(f.get(r) || '').toLowerCase() === String(entity.value).toLowerCase());
      }
      if (ds && period !== 'ALL TIME' && ds.dateField) {
        const rng = periodRange(period, from, to);
        const f = fieldsFor(ds, canSeeMoney).find(x => x.label === ds.dateField);
        if (rng && f) list = list.filter(r => { const v = f.get(r); if (!v) return false; const d = String(v).slice(0, 10); return d >= rng[0] && d <= rng[1]; });
      }
    }
    if (def.filter) {
      const ds = DATASETS[def.ds];
      const conds = ds ? [].concat(def.filter).map(fl => ({ f: fieldsFor(ds, canSeeMoney).find(x => x.label === fl.field), fl }))
        .filter(x => x.f).map(({ f, fl }) => ({ field: f.key, op: fl.op, value: fl.value })) : [];
      if (conds.length) list = applyFilters(list, ds, conds, 'AND', '');
    }
    return list.length;
  }, [datasetKey, scopeRows, entity, period, from, to, canSeeMoney]);
  const tableCols = useMemo(() => columns.map(k => fieldByKey(dataset, k)).filter(Boolean), [columns, dataset]);
  const sortedAll = useMemo(() => {
    const list = viewerRows.slice();
    const fld = sort.col ? fieldByLabelMap[sort.col] : null;
    if (!fld) return list;
    list.sort((a, b) => {
      const av = fld.get(a);
      const bv = fld.get(b);
      let cmp;
      if (fld.type === 'number' || fld.type === 'money' || fld.type === 'percent') cmp = (Number(av) || 0) - (Number(bv) || 0);
      else if (fld.type === 'date') cmp = new Date(av || 0).getTime() - new Date(bv || 0).getTime();
      else cmp = String(av ?? '').localeCompare(String(bv ?? ''));
      return sort.dir === 'desc' ? -cmp : cmp;
    });
    return list;
  }, [viewerRows, fieldByLabelMap, sort]);
  const chartRows = useMemo(() => {
    const def = appliedDef;
    if (!def || !def.groupBy || !chartOn) return [];
    const gf = fieldByLabelMap[def.groupBy];
    if (!gf) return [];
    const mf = def.measure && def.measure.field ? fieldByLabelMap[def.measure.field] : null;
    const meas = def.measure ? { agg: def.measure.agg, field: mf ? mf.key : undefined } : { agg: 'count' };
    const g = groupRows(viewerRows, dataset, [gf.key], [meas]);
    const isTime = /Month|Date|Year|Timestamp/.test(def.groupBy);
    g.sort((a, b) => isTime
      ? String(a.path[0]).localeCompare(String(b.path[0]))
      : (Number(b.values[0]) || 0) - (Number(a.values[0]) || 0));
    return g.slice(0, 24).map(b => ({ id: String(b.path[0]), label: String(b.path[0]), value: Number(b.values[0]) || 0 }));
  }, [viewerRows, dataset, fieldByLabelMap, appliedDef, chartOn]);
  const measureField = appliedDef && appliedDef.measure && appliedDef.measure.field ? fieldByLabelMap[appliedDef.measure.field] : null;
  const fmtChart = useCallback((v) => formatValue(v, measureField ? measureField.type : 'number'), [measureField]);

  const stamp = () => localISO();
  const exportCSV = () => {
    const def = appliedDef;
    if (!def || !tableCols.length) return;
    downloadCSV(
      'GOLDEN_SEED_' + def.id + '_' + stamp() + '.csv',
      toCSV(tableCols.map(c => c.label), sortedAll.map(r => tableCols.map(c => c.get(r)))),
    );
  };
  // fix217 (David): ONE PDF writer (reportPdf.js) -- cover with the chart drawn as shapes, then the table on its own
  // pages, columns sized to their content, long text wrapped, page numbers. The old one drew the table over the cover.
  const exportPDF = async () => {
    const def = appliedDef;
    if (!def || !tableCols.length) return;
    const { writeReportPdf } = await import('./reportPdf');
    await writeReportPdf({
      logoImage: GES_GLOBE,   // fix233
      title: def.title,
      scopeLine: (entity ? entity.type + ' ' + entity.value : 'WHOLE SOURCE') + '  |  ' +
        (def.period ? periodHuman().toUpperCase() : 'AS AT TODAY') + '  |  SORT ' +
        (sort.col || 'DEFAULT') + ' ' + sort.dir.toUpperCase() + '  |  ' + sortedAll.length + ' ROWS',
      description: def.desc,
      chartTypes: chartOn && chartRows.length ? [...new Set(chartModes.map(t => CHART_MAP[t] || 'bars'))] : [],
      chartRows,
      chartFormat: fmtChart,
      cols: tableCols,
      rows: sortedAll,
      format: formatValue,
      fileName: 'GOLDEN_SEED_' + def.id + '_' + stamp() + '.pdf',
    });
  };

  return (
    <div className={styles.studio}>
      <div className={styles.sourceRow}>
        <div className={styles.sourcePanel} ref={sourceRailRef}>
          <div className={styles.tileRow}>
            {available.map(ds => (
              <button key={ds.key} type="button" aria-pressed={ds.key === datasetKey} className={ds.key === datasetKey ? styles.tileActive : styles.tile} onClick={() => setDatasetKey(ds.key)}
                title={'Work with the ' + ds.label + ' data. The number is how many rows are in it for your scope.'}>
                {ds.label}
                <span className={styles.tileCount}>{ds.key === datasetKey && loading ? '...' : scopedCount(ds.key)}</span>
              </button>
            ))}
          </div>
        </div>
        <span className={styles.sourceCount}>{loading ? '...' : scopeRows.length} SOURCE ROWS</span>
      </div>
      <div className={scopeOpen ? styles.scopePanel : styles.scopePanel + ' ' + styles.panelCollapsed}>
        {scopeOpen && <CornerDecor hideTop />}
        <div
          className={styles.panelHeadRow}
          role="button"
          tabIndex={0}
          onClick={() => setScopeOpen(o => !o)}
          onKeyDown={(e) => { if (e.target === e.currentTarget && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); setScopeOpen(o => !o); } }}
          aria-expanded={scopeOpen}
          aria-label="Collapse or expand scope panel"
          title="Who, when, which columns and sort. Press to open or close."
        >
          <span className={styles.scopeTitle}>SCOPE</span>
          <span className={styles.headToggle}>
            <FiChevronDown className={scopeOpen ? styles.pickIconOpen : ''} aria-hidden="true" />
          </span>
        </div>
        <div className={scopeOpen ? styles.scopeBody : styles.panelClosed}>
          {error && <div className={styles.error}><FiAlertCircle size={13} aria-hidden="true" /> {error}</div>}
          {!error && loadNote && <div className={styles.error} role="status"><FiAlertCircle size={13} aria-hidden="true" /> {loadNote}</div>}
          {!canSeeMoney && (
            <p className={styles.hint}>
              <FiAlertCircle size={12} aria-hidden="true" /> Financial datasets, money columns and company reports are hidden on your role.
            </p>
          )}
          <div className={styles.scopeRow}>
            <div className={styles.scopeField} ref={entRef}>
              <span className={styles.miniLabel}>Who / what</span>
              <div className={styles.entWrap}>
                {entity && (
                  <span className={styles.chipE}>
                    {entity.label}: {entity.value}
                    <button onClick={() => setEntity(null)} aria-label="Clear entity" title="Back to the whole company"><FiX size={11} aria-hidden="true" /></button>
                  </span>
                )}
                <input
                  className={styles.entInput}
                  style={{ height: 36, width: 'clamp(200px, 22vw, 260px)', boxSizing: 'border-box' }}
                  value={entQuery}
                  placeholder={entity ? 'Change...' : (SEARCH_HINT[datasetKey] || 'Type to search this source...')}
                  onFocus={() => setEntOpen(true)}
                  onChange={e => { setEntQuery(e.target.value); setEntOpen(true); }}
                  onKeyDown={e => {
                    if (e.key === 'Enter') {
                      if (entMatches[0]) { setEntity(entMatches[0]); setEntQuery(''); setEntOpen(false); }
                      e.preventDefault();
                    }
                  }}
                  aria-label="Search who / what"
                />
                {entOpen && (
                  <div className={styles.pickList} data-ta-list>
                    <div className={styles.ddScroll}>
                      {!entQuery && <button className={styles.pickOption} onClick={() => { setEntity(null); setEntQuery(''); setEntOpen(false); }}>WHOLE COMPANY</button>}
                      {!entQuery && <div className={styles.ddFootMsg}>TYPE TO SEARCH THIS SOURCE -- ENTER PICKS THE FIRST MATCH</div>}
                      {entQuery && entMatches.length === 0 && <div className={styles.ddFootMsg}>NO MATCH IN THIS SOURCE</div>}
                      {entQuery && entMatches.map(m => (
                        <button key={m.type + m.value} className={styles.pickOption} onClick={() => { setEntity(m); setEntQuery(''); setEntOpen(false); }}>
                          {m.value}<span className={styles.pickOptionTag}>{m.label}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
            <div className={styles.scopeField}>
              <span className={styles.miniLabel}>When</span>
              <div className={(appliedDef && !appliedDef.period ? styles.perChipsDim : '') + ' ' + styles.perChips}>
                {PERIODS.map(p => (
                  <button key={p} className={period === p ? styles.pchipOn : styles.pchip} onClick={() => setPeriod(p)} title={p === 'CUSTOM' ? 'Pick your own From and To days' : 'Only what happened in: ' + p.toLowerCase()}>{p}</button>
                ))}
              </div>
              {period === 'CUSTOM' && (
                <div className={styles.customRange}>
                  <HardwareDatePicker value={from} onChange={setFrom} ariaLabel="From date" />
                  <span>to</span>
                  <HardwareDatePicker value={to} onChange={setTo} ariaLabel="To date" />
                </div>
              )}
              {appliedDef && !appliedDef.period && <span className={styles.snapHint}>snapshot -- as at today, period ignored</span>}
            </div>
            <div className={styles.scopeField} ref={colRef} data-ta-field>
              <span className={styles.miniLabel}>Columns</span>
              <button className={styles.pickBtn} onClick={() => setColOpen(o => !o)} aria-expanded={colOpen} title="Pick the columns of the table, the CSV and the PDF. Type a letter to jump.">
                <span>{columns.length} OF {fields.length} COLUMNS</span>
                <FiChevronDown className={colOpen ? styles.pickIconOpen : ''} aria-hidden="true" />
              </button>
              {colOpen && (
                <div className={styles.pickList} data-ta-list>
                  <div className={styles.ddScroll}>
                    {fields.map(f => (
                      <label key={f.key} className={styles.pickCheck + (columns.indexOf(f.key) >= 0 ? ' ' + styles.pickCheckOn : '')}>
                        <input type="checkbox" checked={columns.indexOf(f.key) >= 0} onChange={() => toggleColumn(f.key)} /><span className={styles.pickBox} aria-hidden="true">{columns.indexOf(f.key) >= 0 && <FiCheck />}</span><span>{f.label}</span>
                      </label>
                    ))}
                  </div>
                </div>
              )}
            </div>
            <div className={styles.scopeField} ref={sortRef} data-ta-field>
              <span className={styles.miniLabel}>Sort</span>
              <div className={styles.sortRow}>
                <button className={styles.pickBtn} onClick={() => setSortOpen(o => !o)} aria-expanded={sortOpen} title="Pick the column the rows are sorted by. Type a letter to jump.">
                  <span>{sort.col || 'DEFAULT'}</span>
                  <FiChevronDown className={sortOpen ? styles.pickIconOpen : ''} aria-hidden="true" />
                </button>
                <button className={styles.dirBtn} onClick={() => setSort(s => ({ col: s.col, dir: s.dir === 'desc' ? 'asc' : 'desc' }))} aria-label="Flip sort direction" title={sort.dir === 'desc' ? 'Biggest / newest first. Press for smallest / oldest first.' : 'Smallest / oldest first. Press for biggest / newest first.'}>
                  {sort.dir === 'desc' ? '\u2193' : '\u2191'}
                </button>
                {sortOpen && (
                  <div className={styles.pickList} data-ta-list>
                    <div className={styles.ddScroll}>
                      <button className={styles.pickOption + (!sort.col ? ' ' + styles.pickOptionActive : '')} onClick={() => { setSort({ col: '', dir: 'asc' }); setSortOpen(false); }}>DEFAULT (report's own)</button>
                      {fields.map(f => (
                        <button key={f.key} className={styles.pickOption + (sort.col === f.label ? ' ' + styles.pickOptionActive : '')} onClick={() => { setSort(s => ({ col: f.label, dir: s.dir })); setSortOpen(false); }}>
                          {f.label}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className={(catOpen ? styles.catPanel : styles.catPanel + ' ' + styles.panelCollapsed)}>
        {catOpen && <CornerDecor hideTop />}
        <div
          className={styles.panelHeadRow}
          role="button"
          tabIndex={0}
          onClick={() => setCatOpen(o => !o)}
          onKeyDown={(e) => { if (e.target === e.currentTarget && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); setCatOpen(o => !o); } }}
          aria-expanded={catOpen}
          aria-label="Collapse or expand catalogue panel"
          title="Every ready-made report. Press to open or close."
        >
          <span className={styles.scopeTitle}>REPORT CATALOGUE</span>
          <span className={styles.badge}>{searched.length} MATCHES</span>
          <div className={styles.searchBox} onClick={e => e.stopPropagation()} onKeyDown={e => e.stopPropagation()}>
            <FiSearch className={styles.searchIcon} aria-hidden="true" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search reports..." aria-label="Search reports" style={{ paddingLeft: 40 }} />
            {search && <button className={styles.searchClear} onClick={() => setSearch('')} aria-label="Clear search" title="Clear the search"><FiX size={13} aria-hidden="true" /></button>}
          </div>
          <span className={styles.headToggle}>
            <FiChevronDown className={catOpen ? styles.pickIconOpen : ''} aria-hidden="true" />
          </span>
        </div>
        <div className={catOpen ? styles.catBody : styles.panelClosed}>
          <div className={styles.tabRow}>
            <button className={groupTab === 'ALL' ? styles.gtabOn : styles.gtab} onClick={() => setGroupTab('ALL')} title="Every report, in its groups">
              ALL<span className={styles.gcnt}>{searched.length}</span>
            </button>
            {GROUPS.map(g => {
              const n = searched.filter(d => d.group === g).length;
              if (!n && g !== groupTab) return null;
              return (
                <button key={g} className={groupTab === g ? styles.gtabOn : styles.gtab} onClick={() => setGroupTab(g)} title={'Only the reports about: ' + g.toLowerCase()}>
                  {g}<span className={styles.gcnt}>{n}</span>
                </button>
              );
            })}
          </div>
          {recentDefs.length > 0 && (
            <div className={styles.recentRow}>
              <span className={styles.recentLabel}>RECENTLY USED</span>
              {recentDefs.map(d => (
                <button key={d.id} className={styles.rchip} onClick={() => applyDef(d)} title={'Use again: ' + d.desc}>{d.title}</button>
              ))}
            </div>
          )}
          <div className={styles.catList}>
            {defaultDef && (
              <div className={styles.ungrouped}>
                <div className={styles.groupBody}>
                  {catRowNode(defaultDef, true)}
                </div>
              </div>
            )}
            {restList.length === 0 && !defaultDef && <div className={styles.emptyCell}>NO REPORTS MATCH THIS SCOPE + SEARCH</div>}
            {groupTab === 'ALL'
              ? GROUPS.filter(g => restList.some(d => d.group === g)).map(g => (
                <div key={g} className={styles.group}>
                  <div className={styles.groupLabel}><span>{g} ({restList.filter(d => d.group === g).length})</span></div>
                  <div className={styles.groupBody}>
                    {restList.filter(d => d.group === g).map(d => catRowNode(d))}
                  </div>
                </div>
              ))
              : restList.length > 0 && (
                <div className={styles.ungrouped}>
                  <div className={styles.groupBody}>
                    {restList.map(d => catRowNode(d))}
                  </div>
                </div>
              )}
          </div>
          <div className={styles.foot}>
            {listed.length} report{listed.length === 1 ? '' : 's'} in {groupTab === 'ALL' ? 'all groups' : groupTab}{defaultDef ? ' (+1 default)' : ''}
            {search ? ' matching "' + search + '"' : ''}
            {entity ? ' for ' + entity.label.toLowerCase() + ' ' + entity.value : ' for the whole company'}
            {' · ' + scopeRows.length + ' of ' + rows.length + ' rows in scope'}
          </div>
        </div>
      </div>

      {appliedDef && (
        <div className={styles.viewerPanel}>
          <div className={styles.panelHeadRow}>
            <span className={styles.scopeTitle}>PREVIEW -- {appliedDef.title}</span>
            <div className={styles.pvChips}>
              <span className={styles.pvChip}>{entity ? entity.label.toUpperCase() + ' ' + entity.value : 'WHOLE SOURCE'}</span>
              <span className={styles.pvChip}>{appliedDef.period ? periodHuman().toUpperCase() : 'AS AT TODAY'}</span>
              <span className={styles.pvChip}>SORT {sort.col || 'DEFAULT'} {sort.dir.toUpperCase()}</span>
              <span className={styles.pvChip}>{tableCols.length} COLUMNS</span>
              <span className={styles.pvChip}>{sortedAll.length} ROWS MATCH</span>
              <span className={styles.pvChipDd} ref={chartDdRef} data-ta-field>
                CHART
                <button className={styles.chartDdBtn} onClick={() => setChartOpen(o => !o)} aria-expanded={chartOpen} title="Pick one or more charts (bars, columns, line, donut), or NONE. Type a letter to jump.">
                  {chartOn ? chartModes.join(' + ') : 'NONE'}<FiChevronDown className={chartOpen ? styles.pickIconOpen : ''} aria-hidden="true" />
                </button>
                {chartOpen && (
                  <div className={styles.pickList} data-ta-list>
                    <div className={styles.ddScroll}>
                      {CHART_OPTS.map(t => (
                        <button key={t} className={styles.pickOption + ((t === 'NONE' ? !chartOn : chartModes.includes(t)) ? ' ' + styles.pickOptionActive : '')}
                          aria-pressed={t === 'NONE' ? !chartOn : chartModes.includes(t)}
                          onClick={() => { if (t === 'NONE') { setChartModes([]); setChartOpen(false); } else setChartModes(m => (m.includes(t) ? m.filter(x => x !== t) : [...m, t])); }}>
                          {t === 'NONE' ? t : (chartModes.includes(t) ? '\u2713 ' : '') + t}</button>
                      ))}
                    </div>
                  </div>
                )}
              </span>
            </div>
            <div className={styles.pvBtns}>
              <button className={styles.useBtn} onClick={exportCSV} disabled={!sortedAll.length || !tableCols.length} title="Download every matching row as a CSV file (opens in Excel).">CSV -- THE DATA</button>
              <button className={styles.useBtnDark} onClick={exportPDF} disabled={!sortedAll.length || !tableCols.length} title="Download a PDF: a cover page with the chart, then the whole table with page numbers.">PDF -- THE DOCUMENT</button>
            </div>
          </div>
          <div className={styles.approachNote}>
            CSV = every matching row, flat, for Excel. PDF = one document: a cover page with the scope and the chart, then the whole table on its own pages (landscape, headings on every page, page numbers). The screen table stays a sample so the page stays fast.
          </div>
          {chartOn && chartRows.length > 0 && (
            <div className={chartModes.length > 1 ? styles.chartGrid : undefined} ref={chartRef}>
              {chartModes.map(t => (
                <div key={t} className={styles.chartBox}>
                  <Chart type={CHART_MAP[t] || 'bars'} rows={chartRows} format={fmtChart} />
                </div>
              ))}
            </div>
          )}
          {chartOn && chartRows.length === 0 && (
            <div className={styles.pvNote}>NOTHING TO CHART FOR THIS SCOPE</div>
          )}
          <div className={styles.pvScroll}>
            <table className={styles.pvTable}>
              <thead>
                <tr>{tableCols.map(c => <th key={c.key}>{c.label}</th>)}</tr>
              </thead>
              <tbody>
                {sortedAll.length === 0 && (
                  <tr><td colSpan={Math.max(tableCols.length, 1)} className={styles.emptyCell}>NOTHING MATCHES THIS SCOPE</td></tr>
                )}
                {sortedAll.slice(0, SAMPLE).map((r, i) => (
                  <tr key={i}>
                    {tableCols.map(c => <td key={c.key}>{formatValue(c.get(r), c.type)}</td>)}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className={styles.pvNote}>
            SAMPLE: FIRST {Math.min(SAMPLE, sortedAll.length)} OF {sortedAll.length} ROWS -- CSV AND PDF CARRY ALL OF THEM.
            WIDE TABLE? SCROLL SIDEWAYS, THE FIRST COLUMN STAYS PINNED.
          </div>
        </div>
      )}

      {!appliedDef && (
        <div className={styles.viewerEmpty}>
          PICK A REPORT ABOVE -- ITS LIVE CHART, PREVIEW, CSV AND PDF LAND HERE
        </div>
      )}

      {appliedDef && (
        <div className={styles.appliedLine}>
          APPLIED: <b>{appliedDef.title}</b> &middot; {tableCols.length} columns &middot; sorted {sort.col || 'default'} {sort.dir} &middot; {entity ? entity.label + ' ' + entity.value : 'whole company'} &middot; {appliedDef.period ? periodHuman() : 'right now'}
        </div>
      )}
    </div>
  );
};
export default ReportStudio;
